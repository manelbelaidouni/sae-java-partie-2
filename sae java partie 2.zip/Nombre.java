public class Nombre extends Expression {
    private int valeur;

    public Nombre(int valeur) {
        this.valeur = valeur;
    }

    @Override
    public int valeur() {
        return valeur;
    }

    @Override
    public String toString() {
        return Integer.toString(valeur);
    }
}